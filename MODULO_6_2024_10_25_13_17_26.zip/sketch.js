let palavra;

function setup() {
  createCanvas(400, 400); // criando cenário;
  
  let palavras = ["caminhante", "caminho", "caminha"];
  palavra = random (palavras);// criando variável palavra = caminhante
}

function inicializaCores (){// função para definir a cor do cenario
  background(220); // cor do cenário
  fill("black");// cor da letra
  textSize(64);// tamanho do texto
  textAlign(CENTER, CENTER);// centralizar o texto
}

function draw() { // função de desenho
  inicializaCores();
  
  let maximo = width;// criando variável maximo = largura
  let minimo = 0; // criando variável minimo = 0
  //mouseX, 0, width ==> 0, palavra.length
  
  
  let quantidade = map(mouseX, 0, width, 1, palavra.length); //criando variável quantidade
  //console.log (quantidade);
  let parcial = palavra.substring(0, quantidade);// criando variável parcial
  text(parcial, 200, 200);// tamanho do texto parcial
  

  }